# AI Handover

Treat this file as the entry point for future agents.

Do not assume recommendations are implemented unless marked confirmed.
Keep a decision log.
Protect the visual identity:
warm garden, flowers first, readable gameplay, controlled variation.
