# Bloomhaven — Garden of Wonders

A cozy botanical garden game direction focused on flowers, cultivation,
discovery, collection, genetics and calm garden management.

Core pillars:
- Flowers as visual heroes
- Warm restorative world
- Readable mobile garden camera
- Visible plant variation
- Calm premium UI

Current art direction:
Stylized botanical 3D / painterly garden diorama.
