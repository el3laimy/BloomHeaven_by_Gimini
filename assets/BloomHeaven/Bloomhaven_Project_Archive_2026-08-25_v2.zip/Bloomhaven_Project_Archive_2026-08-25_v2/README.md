# Bloomhaven Project Archive Snapshot
Date: 2026-08-25

This archive is a structured handover package for Bloomhaven.
It contains project identity, art direction notes, requirements, decisions,
technical baseline, asset inventory, current status, and AI handover notes.
