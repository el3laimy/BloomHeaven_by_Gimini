# Decisions Log

- Preserve Fiona Finch visual DNA: gardens, flowers, discovery, relaxation.
- Upgrade to modern stylized 3D presentation.
- Prioritize readability and production feasibility.
- Keep genetics connected to visible plant phenotype.
